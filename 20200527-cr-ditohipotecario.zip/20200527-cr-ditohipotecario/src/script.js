function limpiar(){
  alert ("Limpiaremos")
  document.frmHipotecario.txtNombre.value="";
  document.frmHipotecario.txtEdad.value="";
  document.frmHipotecario.txtValorPropiedad.value="";
  
  document.frmHipotecario.cmbRangoSalario.value="0";
  document.frmHipotecario.cmbEstadoCivil.value="0";
  
  document.frmHipotecario.radSexo[0].checked=false;
  document.frmHipotecario.radSexo[1].checked=false;
  
}

function validar(){
  var UF="28500";
  var Edad=document.frmHipotecario.txtEdad.value;
  var RangoSalario=document.frmHipotecario.cmbRangoSalario.value;
  var ValorPropiedad=document.frmHipotecario.txtValorPropiedad.value;
  var EstadoCivil=document.frmHipotecario.cmbEstadoCivil.value;

    if (Edad<80 && RangoSalario>3 && ValorPropiedad<=3000){
      alert ("SI PUEDE CONTINUAR")  
    }else{
      if (Edad>50 && document.frmHipotecario.radSexo[1].value=="Mujer" && EstadoCivil=="Soltero" && ValorPropiedad<=3000){
        alert ("SI PUEDE CONTINUAR")
      }else{
        if (Edad>60 && document.frmHipotecario.radSexo[0].value=="Hombre" && EstadoCivil=="Soltero" && ValorPropiedad<=3000){
          alert ("SI PUEDE CONTINUAR")
        }else{
          alert ("NO CUMPLE CON LAS CONDICIONES")
        }
      }
    }
}

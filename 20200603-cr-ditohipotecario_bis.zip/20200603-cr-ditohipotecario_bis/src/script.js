function validarNombre() {
  var Nombre = document.getElementById("txtNombre").value;
  var Vocal = Nombre.charAt(0);
  if (Vocal == "A" || Vocal == "a" || Vocal == "E" || Vocal == "e" || Vocal == "I" || Vocal == "i" || Vocal == "O" || Vocal == "o" || Vocal == "U" || Vocal == "u") {
      document.getElementById("mensajeNombre").innerHTML = "vamos bien";
    }else{
        document.getElementById("mensajeNombre").innerHTML = "mal";
    }
}

function validarEdad() {
  var Edad = document.getElementById("txtEdad").value;
    if (Edad<50){
      document.getElementById("mensajeEdad").innerHTML = "vamos bien";
    }else{
        document.getElementById("mensajeEdad").innerHTML = "mal";
    }
}

function validarEstadoCivil() {
  var EstadoCivil = document.frmHipotecario.cmbEstadoCivil.value;
    if (EstadoCivil == "Soltero"){
      document.getElementById("mensajeEstadoCivil").innerHTML = "vamos bien";
    }else{
        document.getElementById("mensajeEstadoCivil").innerHTML = "mal";
        }
}

function validarSalario() {
  var Salario = document.frmHipotecario.txtSalario.value;
    if (Salario>1500000){
      document.getElementById("mensajeSalario").innerHTML = "vamos bien";
    }else{
        document.getElementById("mensajeSalario").innerHTML = "mal";
        }
}

function validarDividendo() {
  var UF="28500";
  var Salario = document.frmHipotecario.txtSalario.value;
  var Propiedad = document.frmHipotecario.txtValorPropiedad.value;
  var AñosCred = document.frmHipotecario.txtAñosCredito.value;
  var Dividendo = (Propiedad*UF) * 1.05 / (AñosCred*12)
  //var res = Salario * 0.25
  document.getElementById("calculoDividendo").innerHTML="$" + Dividendo;
  if (Dividendo<(Salario*0.25)){
  document.getElementById("mensaje").innerHTML="Aprobado";
  }else{
    document.getElementById("mensaje").innerHTML="Rechado";
    }
}


  function limpiar(){
  alert ("Limpiaremos")
    
  document.frmHipotecario.txtNombre.value="";
  document.frmHipotecario.txtEdad.value="";
  document.frmHipotecario.txtValorPropiedad.value="";
  document.frmHipotecario.txtSalario.value="";
  document.frmHipotecario.txtAñosCredito.value="";
  
  document.frmHipotecario.cmbEstadoCivil.value="0";
  
  document.frmHipotecario.radSexo[0].checked=false;
  document.frmHipotecario.radSexo[1].checked=false;
    
  //aquí quería borrar el valor del dividendo y si está aprobado, pero no pude. Espero hacerlo pronto.
 
}


function validar(){
  var AprobadoQSY = document.getElementById("mensaje").innerHTML;
    if (AprobadoQSY=="Aprobado"){
      alert ("SI PUEDE CONTINUAR")  
        }else{
          if (AprobadoQSY=="Rechado"){
          alert ("NO CUMPLE CON LAS CONDICIONES")
          }
        }
}

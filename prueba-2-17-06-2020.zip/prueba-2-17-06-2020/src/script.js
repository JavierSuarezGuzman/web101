function abrirCertificado() // esto mostrará un mensaje alert si el alumno tiene nota azul para aprobar
{
  var nombre = document.frmNotas.txtAlumno.value;
  var notaFinal = document.getElementById("msjPromedioFinal").innerHTML;
  if (notaFinal >= 40){
  alert("Alumno " + nombre + " APRUEBA");
    }else{
      alert("Alumno " + nombre + " REPRUEBA :(");
    }
  
}
function limpiar() // limpiará todo el formulario con un alert dando aviso
{
  alert("Limpiaremos el formulario por ti, para que puedas ingresar otro alumno");
  document.frmNotas.txtAlumno.value="";
  document.frmNotas.txtNota1.value="";  
  document.frmNotas.txtNota2.value="";
  document.frmNotas.txtNota3.value="";
  document.frmNotas.txtExamen.value="";
  document.getElementById("msjPromedioAE").innerHTML = "";
  document.getElementById("msjRealizaExamen").innerHTML = "";
  document.getElementById("msjPromedioFinal").innerHTML = "";
}

function ayuda() // subirá las 3 notas y el examen en un 10% para luego recalcular sobre Promedio Final
{
  alert("Esta ayuda subirá las notas un 10% y calculará el Promedio Final una vez más");
  var nota1= document.frmNotas.txtNota1.value;
  var nota2= document.frmNotas.txtNota2.value;
  var nota3= document.frmNotas.txtNota3.value;
  var notaE= document.frmNotas.txtExamen.value;
  nota1= nota1*1.1;
  nota2= nota2*1.1;
  nota3= nota3*1.1;
  notaE= notaE*1.1;
  var promedioFinal=(((Number(nota1)+Number(nota2)+Number(nota3))/3)*0.6)+(Number(notaE)*0.4);
  document.getElementById("msjPromedioFinal").innerHTML = promedioFinal;
}

function promedio(){ // sacará el promedio de presentación de examen y de tener nota sobre 55 finalizará
  var nota1= document.frmNotas.txtNota1.value;
  var nota2= document.frmNotas.txtNota2.value;
  var nota3= document.frmNotas.txtNota3.value;
  var promedio=(Number(nota1)+Number(nota2)+Number(nota3))/3;
  document.getElementById("msjPromedioAE").innerHTML = promedio;
  document.getElementById("txtExamen").value = promedio;
  var notaExamen= document.getElementById("txtExamen").value;
    if (promedio>55){
      document.getElementById("msjRealizaExamen").innerHTML = "NO";
      document.getElementById("msjPromedioFinal").innerHTML = promedio;
      }else{
        document.getElementById("msjRealizaExamen").innerHTML = "SI";
    }
}

function promedio2(){ // este promedio2 nos servirá cuando la nota de presentación requiera rendir examen:38 HTML
  var nota1= document.frmNotas.txtNota1.value;
  var nota2= document.frmNotas.txtNota2.value;
  var nota3= document.frmNotas.txtNota3.value;
  var promedio=(Number(nota1)+Number(nota2)+Number(nota3))/3;
  var notaExamen= document.getElementById("txtExamen").value;
    document.getElementById("msjPromedioFinal").innerHTML = (Number(promedio)*0.6) + (Number(notaExamen)*0.4);
    }
